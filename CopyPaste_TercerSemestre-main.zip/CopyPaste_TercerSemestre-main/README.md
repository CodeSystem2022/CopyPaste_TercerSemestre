# CopyPaste - Tercer Semestre Año 2023

![Logo Copy:Paste](https://user-images.githubusercontent.com/103675851/232830051-f665dac5-7813-4c63-8612-a451b562bdf7.jpg)

<div id="header" align="end">
		<h3 align="end">Repositorio del grupo Copy Paste</h3>
		<h4 align="end">En este repositorio se encuentran las actividades semanales del grupo</h4>
</div>

<div >
	<h3> 📚 Materias del repositorio: </h3>
  <br>
  <h4 align="center" >Programación III | Laboratorio III </h4>
  <h3> 🗂 Lenguajes del repositorio:</h3>
	<br>
  <div align="center">
	<img src="https://github.com/devicons/devicon/blob/master/icons/javascript/javascript-plain.svg" title="JavaScrip" alt="JS" width="40" height="40">&nbsp;
	<img src="https://github.com/devicons/devicon/blob/master/icons/java/java-plain.svg" title="Java" alt="JAVA" width="40" height="40">&nbsp;
	<img src="https://github.com/devicons/devicon/blob/master/icons/python/python-original.svg" title="Python" alt="PYTHON" width="40" height="40">&nbsp;
  <br>
  </div>
</div>
<h2><srong><u> 👤 Integrantes</u></srong></h2>
<div align="center">	
<h3>	  
  Britez Neira Leila
  <br>
  Solán Leonardo
  <br>
  Viola Jésica
	
 </div>
 
<h2> 📆 Organización Semanal </h2>
 
<table align="center">
	<tr>
		<th>SEMANA</th>
		<th>SCRUM MASTER</th>
	</tr>
	<tr>
		<td>1°</td>
		<td>Britez Neira Leila</td>
	</tr>
	<tr>
		<td>2°</td>
		<td>Solán Leonardo</td>
	</tr>
	<tr>
		<td>3°</td>
		<td>Viola Jésica</td>
	</tr>
	<tr>
		<td>4°</td>
		<td>Britez Neira Leila</td>
	</tr>
	<tr>
		<td>5°</td>
		<td>Solán Leonardo</td>
	</tr>
	<tr>
		<td>6°</td>
		<td>Viola Jésica</td>
	</tr>
		<tr>
		<td>7°</td>
		<td>Britez Neira Leila</td>
	</tr>
	<tr>
		<td>8°</td>
		<td>Solán Leonardo</td>
	</tr>
	<tr>
		<td>9°</td>
		<td>Viola Jésica</td>
	</tr>
  	<tr>
		<td>10°</td>
		<td>Britez Neira Leila</td>
	</tr>
	<tr>
		<td>11°</td>
		<td>Solán Leonardo</td>
	</tr>
	<tr>
		<td>12°</td>
		<td>Viola Jésica</td>
	</tr>
</table>
